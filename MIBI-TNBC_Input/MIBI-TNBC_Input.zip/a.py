import os
import numpy as np

folder = "."   # 就是当前 MIBI-TNBC_Input 目录

labels = []

for fname in os.listdir(folder):
    if fname.endswith("_GraphLabel.txt"):
        path = os.path.join(folder, fname)
        v = np.loadtxt(path, dtype=int)
        labels.append(int(v))
        print(f"{fname} -> {int(v)}")

print("图像总数:", len(labels))
print("不同标签集合:", sorted(set(labels)))
